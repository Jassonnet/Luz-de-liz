// Aquí irá el carrito en la próxima parte
console.log("Luz de Liz cargado correctamente.");
